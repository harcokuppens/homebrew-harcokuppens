.. TorXakis documentation master file, created by
   sphinx-quickstart on Tue Sep 26 15:45:45 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to TorXakis's documentation!
====================================

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   tutorial/index.rst
