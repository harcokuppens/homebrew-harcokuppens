TorXakis - Model Based Testing
Copyright (c) 2015-2017 TNO and Radboud University
See LICENSE at root directory of this repository.

CustomersOrders.XSD taken from https://msdn.microsoft.com/en-us/library/bb675181.aspx
CustomersOrders.XML taken from https://msdn.microsoft.com/en-us/library/bb387025.aspx