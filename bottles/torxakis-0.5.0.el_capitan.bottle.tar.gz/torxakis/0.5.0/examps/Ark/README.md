Noah's Ark example.

Taken from http://www.data2type.de/en/xml-xslt-xslfo/schematron/schematron-introduction/

Note: Solving this problem is time consuming since 
the subproblems are large and hard for current SMT solvers.
