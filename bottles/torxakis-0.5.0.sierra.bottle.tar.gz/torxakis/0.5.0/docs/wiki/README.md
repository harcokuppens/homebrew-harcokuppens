Wiki source for TorXakis
========================

The Wiki documentation is built
using [Sphinx](http://www.sphinx-doc.org/en/stable/), and it is hosted
on [Read the Docs](http://readthedocs.io).

To build the documentation run:

```sh
make html
```
